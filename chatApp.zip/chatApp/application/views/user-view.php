<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url()?>public/css/bootstrap.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url()?>public/css/styles.css">
	<link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>

	<script src="<?php echo base_url()?>public/js/jquery.min.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>public/js/emp.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>public/js/jquery.js" type="text/javascript"></script>
	<script src="<?php echo base_url()?>public/js/bootstrap.js" type="text/javascript"></script>
</head>
<style type="text/css">
	
	body{
		padding-top: 10px;
		/*background-image: url("public/img/bckg.png");
		background-size: 600px;
    	background-repeat: no-repeat;*/
		background: #03C9A9; 
		 font-family: Menlo, 'Bitstream Vera Sans Mono', 'DejaVu Sans Mono', Monaco, Consolas, monospace;
		}
	.password {
		font-size: 24px;
	}

	.jumbotron {
		width: 330px;
		height: 380px;
	}

	#username {
		height: 40px;
		border-radius: 10px;
		width: 400px;
		float: right;
	}

	#Password {
		height: 40px;
		border-radius: 10px;
		width: 400px;	
		float: right;
		margin-left: 5px;
	}

	#UserName {
		height: 40px;
		border-radius: 10px;
		width: 400px;	
	}
	#Email {
		height: 40px;
		border-radius: 10px;
		width: 400px;	

	}
	#uPassword {
		height: 40px;
		border-radius: 10px;
		width: 400px;	
	}
	#Confirm_Password {
		height: 40px;
		border-radius: 10px;
		width: 400px;	
	}
	.btn {
		height: 40px;
		border-radius: 10px;	
	}

	.form-control {
		height: 40px;
		border-radius: 10px;	
	}
</style>
<!-- background: -webkit-linear-gradient(	 #0047b3,  #0052cc,#005ce6, #0066ff, #1a75ff, #3385ff, #4d94ff, #66a3ff, #80b3ff, #99c2ff, #b3d1ff, #cce0ff, #e6f0ff, #ffffff);
 -->
 <body>

 <?php 
 echo validation_errors();
  ?>
<div class="container">


<div id="login_form" align="center" class="container" style="position: absolute;  top: 96px; ">
	<div>
		<i class="fa fa-cloud fa-5x"></i>
		<i class="fa fa-envelope fa-5x"></i>
		<i class="fa fa-comment-o fa-5x"></i>
		<i class="fa fa-chrome fa-5x"></i>
		<i class="fa fa-comments-o fa-5x"></i>
		<br />
		<h1 style="margin-left: 8px; font-size: 72px">Data Nerds</h1>
		<h3 style="">(Ask. Inform. Socialize. Gather.)</h3>
	</div>
	
	<div style="background: #F2F1EF; padding: 15px; border-radius: 15px; width: 500px;">
    <?php 
		$form_attrib = array(
			'id' => 'loginForm'
			);

		echo form_open('user/login', $form_attrib); 
	?>
    	<center><h2 style="font-size: ;">Login</h2></center>
       <div>
       <i class="fa fa-user fa-3x"></i>
     <?php 

		$attrib = array(
			'id' => 'username',
			'placeholder' => 'Enter your username',
			'name' => 'username',
			'class' => 'form-control'
			);


		echo form_input($attrib);
      ?>
       </div>
       <br />
       <div class="form-group">
           <i class="fa fa-barcode fa-3x"></i>
           <?php 

				$attrib = array(
					'id' => 'Password',
					'placeholder' => 'Password',
					'name' => 'password',
					'class' => 'form-control'
					);


			echo form_password($attrib);
            ?>
       </div>
       <?php 
			echo form_submit(array( 'type' => 'submit','value' => 'Login' , 'class' => 'btn btn-success btn-block'));
			echo form_close();
        ?>
        <button onclick="$('#myModal').modal('show');" class="btn btn-primary btn-lg btn-block">Not yet registered?</button>
            <!-- <button type="submit" class="btn btn-success btn-block" name="Submit" value="Login">Login</button> --> 
  </div>


</div>

</div>
<div class="modal fade" id="myModal" align="center" style="height: 500px;">
  <div class="modal-dialog field_set" style="width: auto; padding: 20px">
    <div class="modal-content" style="width: auto; padding: 20px height: auto; background: #F2F1EF;">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
       <?php 	
	        	$form_attrib = array(
					'id' => 'regForm',
					'role' => 'form',
				);

				echo form_open('user/register', $form_attrib);
			 ?>
			<center><h2 style="font-size: ;">Register</h2></center>          
            <div class="form-group" >
             
                 <?php 
					$attrib = array(
						'id' => 'UserName',
						'name' => 'username',
						'placeholder' => 'Enter your desired username',
						'class' => 'form-control'
						);
					echo form_input($attrib);
	             ?>
            </div>

            <div class="form-group">
              
              <?php 
				$attrib = array(
					'id' => 'Email',
					'name' => 'email',
					'placeholder' => 'Enter a valid E-mail',
					'class' => 'form-control'
					);

				echo form_input($attrib);
             ?>
            </div>
        
            <div class="form-group">
                          <?php 
				$attrib = array(
					'id' => 'uPassword',
					'name' => 'password',
					'placeholder' => 'Enter password',
					'class' => 'form-control'
					);

				echo form_password($attrib);
             ?>
            </div>
            <div class="form-group">
				<?php 
					$attrib = array(
						'id' => 'Confirm_Password',
						'name' => 'passconf',
						'placeholder' => 'Confirm your password',
						'class' => 'form-control'
						);

					echo form_password($attrib);
				 ?>
            </div>
            <div class="form-group">
            	<?php echo form_submit( array( 'type' => 'submit','value' => 'Register' , 'class' => 'btn btn-success btn-block')); ?>
            </div>
        <?php 	
		echo form_close();
	?>

    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal --> 

</body>
</html>