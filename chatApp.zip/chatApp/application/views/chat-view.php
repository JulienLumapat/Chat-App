<html>

  <title>DISQUS</title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>public/css/bootstrap.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" type="text/css" href="<?= base_url()?>public/css/styles.css">
  <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet' type='text/css'>

  <script src="<?php echo base_url()?>public/js/jquery.min.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>public/js/emp.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>public/js/jquery.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>public/js/bootstrap.js" type="text/javascript"></script>
  <script src="<?php echo base_url()?>public/js/bootstrap.min.js" type="text/javascript"></script>

  <style type="text/css">
    textarea {
      resize: none;
    }
    
    body {
      font-weight: bold;
    } 

    .navbar {
      background-color: #26A65B;
      height: 30px;
      padding-top: 1px;
    }

    .navbar-brand {

      margin-top: 0px;

    }

    li {
      padding-left: 100px;
    }

    .round-button {
      width:25%;
      position: absolute; 
      top: 1px;
    }
    .round-button-circle {
      width: 100px;
      height: auto;
        border-radius: 50%;
      border:10px solid #cfdcec;
        overflow:hidden;
        
        background: #4679BD; 
        box-shadow: 0 0 3px gray;
    }
    .round-button-circle:hover {
      background:#30588e;
    }
    .round-button a {
        display:block;
      float:left;
      width:100%;
      padding-top:50%;
        padding-bottom:50%;
      line-height:1em;
      margin-top:-0.5em;
        
      text-align:center;
      color:#e2eaf3;
        font-family:Verdana;
        font-size:1.2em;
        font-weight:bold;
        text-decoration:none;
    }


  </style>
<head>
  <script> 
    var time = 0;
    var rtime = 0;
    var room = 1;
    var user_id = "<?= $this->session->userdata('id')?>";
  
    var updateTime = function (cb) {
      $.getJSON("http://localhost:8080/chatApp/index.php/chat/time", function (data) {
          cb(~~data);
      });
    };
    
    var sendChat = function (message, cb) {
      var audioElement = document.createElement('audio');
        audioElement.setAttribute('src', '<?= base_url()?>public/sound/ntf.mp3');
        audioElement.setAttribute('autoplay', 'autoplay');
        audioElement.play();

      $.getJSON("http://localhost:8080/chatApp/index.php/chat/insert_chat?message=" + message + "&room=" + room, function (data){
        cb();
      });

    }
    
    var addDataToReceived = function (arrayOfData) {
      arrayOfData.forEach(function (data) {
        if (data[3] == user_id) {
        $("#received").val($("#received").val() + "\n"
          + "___________________________________________________________________________________________________________\n" 
          + data[2] + "\t(" + data[4] + ")\n" + "Message: \n\t\t"  + data[0])
        + "___________________________________________________________________________________________________________";
        } 
        else 
        {
          $("#received").val($("#received").val() + "\n"
          + "___________________________________________________________________________________________________________\n" 
          + data[2] + "\t(" + data[4] + ")\n" + "Message: \n\t\t" + data[0])
          + "___________________________________________________________________________________________________________";
        }

        
      });

    }

    var addDataToTopics = function (arrayOfData) {        
      $("#topics").empty();
      arrayOfData.forEach(function (data) {
         var contents = "<button id=" + data[2] + " class='form-control' style='height: 70px; text-align: left;' onclick=getChat_room_chats("+data[2]+") >"+ data[1] + " by " + data[0] + "</button>";
        
        $("#topics").append(contents);
      });
    }
    
    var getNewChats = function () {
      $.getJSON("http://localhost:8080/chatApp/index.php/chat/get_chats?time=" + time + "&room=" + room, function (data){
        addDataToReceived(data);
        // reset scroll height
        setTimeout(function(){
           $('#received').scrollTop($('#received')[0].scrollHeight);
        }, 0);
        time = data[data.length-1][1];
      });      
    }


    var getNewRooms = function () {
      $.getJSON("http://localhost:8080/chatApp/index.php/chat/get_rooms?time=" + rtime, function (data){
        addDataToTopics(data);
        // reset scroll height
        setTimeout(function(){
           $('#topics').scrollTop($('#topics')[0].scrollHeight);
        }, 0);
        rtime = data[data.length-1][1];
      });      
    }
  
    // using JQUERY's ready method to know when all dom elements are rendered
    $( document ).ready ( function () {
      // set an on click on the button
      $("#chat").submit(function (evt) {
        evt.preventDefault();
        var data = $("#text").val();
        $("#text").val('');

        // get the time if clicked via a ajax get queury
        sendChat(data, function (){
          alert("dane");
        });
      });

      setInterval(function (){
         getNewRooms(0);
      },5000);
    

      setInterval(function (){
        getNewChats(0);
     
      },1500);

      
    });

    function getChat_room_chats(id) {
      room = id;
      time = 0;

     $('#received').val('');  
    }

    function showModal() {
      $('#myModalcreate').modal('show');
    }

    
  </script>
</head>
<body>
<nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><img src="<?= base_url()?>public/img/admin.png" style="height: 70px;position: absolute; top: 1px; float: left;"></a>
        </div> 
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav">
          <li style="margin-top: 27px; font-size: 24px; margin-bottom: 2px; color: #FFF;"><?= $this->session->userdata('username')?></li>
          <li  style="margin-left: 100px;" >
          <div class="round-button">
          <button class="btn round-button-circle" onclick="showModal()">
          <i class="fa fa-comment-o fa-3x">
          </i>
          </button>
          </div>
          </li>
          
          </ul>
          <ul class="nav navbar-nav navbar-right">
          <li>
          <div class="round-button">
          <?= form_open('user/logout'); ?>
          <button type="submit" class="btn round-button-circle"><i class="fa fa-power-off fa-3x"></i></button>
          <?= form_close();?>
          </div>
          </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>


<div class="container-fluid">

<div class="pull-left" id="topics" style="width: 359px; height: 500px; font-weight: bold; border: 1px solid #000; overflow: auto; padding: 0px;"></div>
  <div style="float: right; padding-right: 50px; padding-top: -10px;" class="pull-right">
  <textarea id="received" disabled="disabled" style="width: 900px; height: 500px; font-weight: bold;">
  </textarea>
  <form id="chat">
    <textarea id="text" type="text" name="user" class="form-control" ></textarea>
    <button type="submit" class="btn btn-warning">
      <i class="icon-envelope icon-white"></i> Send
    </button>
  </form>
  </div>




<div class="modal fade" id="myModalcreate" align="center" style="width: 520px; height: 300px;">
  <div class="modal-dialog field_set" style="width: 500px;">
    <div class="modal-content" >
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
      </div>
      <div class="modal-body container-fluid" >
         <?php 
    $form_attrib = array(
      'id' => 'loginForm'
      );

    echo form_open('chat/new_room', $form_attrib); 
  ?>
       <div class="form-group">
         <label for="topicname"><h3>New topic name</h3></label><br>
     <?php 

    $attrib = array(
      'id' => 'topicname',
      'placeholder' => 'Name of Topic',
      'name' => 'topicname',
      'class' => 'form-control'
      );


      echo form_input($attrib);
      echo form_submit(array( 'type' => 'submit', 'value' => 'Create' , 'class' => 'btn btn-success btn-block'));
      echo form_close();
        ?>
      </div>
    </div><!-- /.modal-content -->
  </div><!-- /.modal-dialog -->
</div><!-- /.modal --> 

</div>
</body>
</html>
