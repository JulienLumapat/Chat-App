<?php

class Chat_model extends CI_Model {
  
  function __construct() 
  {
    /* Call the Model constructor */
    parent::__construct();
    
  }

  function get_last_item()
  {
    $this->db->order_by('id', 'DESC');
    $query = $this->db->get('Chats', 1);
    return $query->result();
  }
  
  
  function insert_message($message, $userid, $chatRoom_id)
  {
    $this->message = $message;
    $this->user_id = $userid;
    $this->chat_room_id = $chatRoom_id;
    $this->time = time();  
    $this->db->insert('Chats', $this);
  }

  function get_chat_after($time, $id)
  {

    $array = array('time >' => $time, 'chat_room_id' => $id);
    $this->db->where($array)->order_by('time', 'DESC')->limit(10); 
    $query = $this->db->get('Chats');
    
    $results = array();
    
    foreach ($query->result() as $row)
    {

       $query_user = $this->db->get_where('users', array('user_id' => $row->user_id));
      

      $results[] = array($row->message, $row->time, $query_user->result()[0]->user_name, $row->user_id, $query_user->result()[0]->user_email);
       
    }
    
    return array_reverse($results);
  }

  function get_room_after($time)
  {
 
    $query = $this->db->get('chat_rooms');
    
    $results = array();
    
    foreach ($query->result() as $row)
    {

       $query_user = $this->db->get_where('users', array('user_id' => $row->user_id));
      

      $results[] = array($query_user->result()[0]->user_name, $row->chat_room_name, $row->chat_room_id);
       
    }
    
    return $results;
  }

  function create_table()
  { 
    /* Load db_forge - used to create databases and tables */
    $this->load->dbforge();
    
    /* Specify the table schema */
    $fields = array(
                    'id' => array(
                                  'type' => 'INT',
                                  'constraint' => 5,
                                  'unsigned' => TRUE,
                                  'auto_increment' => TRUE
                              ),
                    'message' => array(
                                  'type' => 'TEXT'
                              ),
                    'time' => array(
                        'type' => 'INT'
                      )
              );
    
    /* Add the field before creating the table */
    $this->dbforge->add_field($fields);
    
    
    /* Specify the primary key to the 'id' field */
    $this->dbforge->add_key('id', TRUE);
    
    
    /* Create the table (if it doesn't already exist) */
    $this->dbforge->create_table('Chats', TRUE);
  }

  function create_new_room($rawData) {

    $result = $this->db->get_where('chat_rooms', array('chat_room_name' => $rawData['chat_room_name']));
    if($result->num_rows() > 0) {
           return false;

    }
    else 
    {
      if($this->db->insert('chat_rooms', $rawData)) {
          return true;
        } else {
          return false;
        }
       }
  }


}