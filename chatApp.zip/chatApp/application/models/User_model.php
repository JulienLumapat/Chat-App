<?php 


/**
* 
*/
class User_model extends CI_Model
{
	
	function __construct()
	{
		parent::__construct();
	}

	function validate_credentials($username, $password) {

		$result = $this->db->get_where('users', array('user_name' => $username, 'user_pass' => $password));

		if ($result->num_rows() > 0) {
			return $result->result();
		} 
		else 
		{
			return null;
		}
	}

	function get_user_info() {

	}

	function create_new_user($rawData) {
	
	$result = $this->db->get_where('users', array('user_name' => $rawData['user_name']));
    
    if($result->num_rows() > 0) {
           return false;
    }
    else 
    {
     if($this->db->insert('users', $rawData)) {
			return true;
		} else {
			return false;
		}
       
    }

	}


}

 ?>