<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
* 
*/
class User extends CI_Controller
{
	
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('User_model');
		$this->load->helper(array('form', 'url'));

		$this->load->library('form_validation');
	}

	function index() {
		$this->load->view('user-view');
	}

	function login() {
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]');

		if ($this->form_validation->run() == FALSE) {
			
			$this->load->view('user-view');
			$this->form_validation->set_message('rule', 'Error Message');
		 
		} else {
			$username = $this->input->post('username');
			$password = $this->input->post('password');

			$result = $this->User_model->validate_credentials($username, $password);

			if (!empty($result)) {

				$newdata = array(
                   'id'  => $result[0]->user_id,
                   'username'  => $result[0]->user_name,
                   'email'     => $result[0]->user_email,
                   'logged_in' => TRUE
               );

				$this->session->set_userdata($newdata);
				echo "<script type='text/javascript'>alert('Login Successful.')</script>";
				redirect('chat');
			}
			else 
			{
				echo "<script type='text/javascript'>alert('Login failed. Please try again.')</script>";
				redirect(base_url());
			}
		}
	}

	function register() {

		
		$this->form_validation->set_rules('username', 'Username', 'trim|required|min_length[6]|max_length[12]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[6]|matches[passconf]');
		$this->form_validation->set_rules('passconf', 'Password Confirmation', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');
		
		if ($this->form_validation->run() == FALSE)
		{
			$this->load->view('user-view');
			$this->form_validation->set_message('rule', 'Error Message');
		} else {
			$username = $this->input->post('username');
			$email = $this->input->post('email');
			$password = $this->input->post('password');

			$insert = array(
			'user_name' => $username,
			'user_email' => $email,
			'user_pass' => $password
			);

			$result = $this->User_model->create_new_user($insert);

			if ($result) {
				echo "<script type='text/javascript'>alert('Registration Successful.')</script>";
				
			} else {
				echo "<script type='text/javascript'>alert('Registration Failed.')</script>";
			}

			redirect(base_url());
		}

	}

	function logout() {
		$array_items = array('id' => '', 'username' => '', 'email' => '', 'logged_in' => FALSE);

		$this->session->unset_userdata($array_items);
		$this->session->sess_destroy();
		redirect(base_url());
	}
}

?>